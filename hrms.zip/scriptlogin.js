document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');

  loginForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const role = document.getElementById('role').value;

    if (role === 'hr') {
      window.location.href = 'hr.html'; // Redirect to HR page
    } else if (role === 'employee') {
      window.location.href = 'employee.html'; // Redirect to Employee page
    } else {
      alert('Please select a role.');
    }
  });
});
