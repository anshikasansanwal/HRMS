document.addEventListener('DOMContentLoaded', () => {
    const employeeInfoForm = document.getElementById('employeeInfoForm');
    const employeeInfoList = document.getElementById('employeeInfoList');
  
    // Submit Employee Information
    employeeInfoForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const employeeID = document.getElementById('employeeID').value;
      const name = document.getElementById('employeeName').value;
      const position = document.getElementById('employeePosition').value;
      const department = document.getElementById('employeeDepartment').value;
      const email = document.getElementById('employeeEmail').value;
      const joiningDate = document.getElementById('employeeJoiningDate').value;
  
      const listItem = document.createElement('li');
      listItem.innerHTML = `
        <strong>ID:</strong> ${employeeID} <br>
        <strong>Name:</strong> ${name} <br>
        <strong>Position:</strong> ${position} <br>
        <strong>Department:</strong> ${department} <br>
        <strong>Email:</strong> ${email} <br>
        <strong>Joining Date:</strong> ${joiningDate}
      `;
      employeeInfoList.appendChild(listItem);
      employeeInfoForm.reset();
    });
  
    // Other event listeners and functionality for Leave Tracking, Performance Evaluation, Document Management, etc.
  });
  